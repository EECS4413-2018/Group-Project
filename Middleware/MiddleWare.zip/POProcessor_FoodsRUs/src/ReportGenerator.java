import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ReportGenerator
{

	public static void main(String[] args)
	{
		
		String dir1 = "/home/user/PO";
		File file = new File(dir1);
		if(file.exists()) {
		String [] allPos = new File(dir1).list(); 
		List<String> unprocessedPos= new ArrayList<String>(); 
		for(int i=0; i< allPos.length;i++) {
			if(allPos[i].charAt(0)!='*') {
				unprocessedPos.add(allPos[i]); 
			}
		}
		
		Unionizer union = new Unionizer(); 
		union.UnionizeXML(unprocessedPos); 
		}

	}

}
