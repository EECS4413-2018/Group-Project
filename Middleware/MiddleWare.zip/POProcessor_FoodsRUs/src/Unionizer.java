import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class Unionizer
{
	
	/* Unionizies all POs to obtain the total quantity of each item to
	 be supplied, it generates a report that lists each item by number
	 and quantity ONLY, everything else is assumed to be consumer fluff*/
	public void UnionizeXML (List<String> POs) {
		
		 try {

				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				
				
				// root elements
				Document doc = docBuilder.newDocument();
				Element rootElement = doc.createElement("orders");
				doc.appendChild(rootElement);
				Attr total = doc.createAttribute("total");
				total.setValue(""+POs.size());
				rootElement.setAttributeNode(total); 
				Attr generated= doc.createAttribute("generated");
				generated.setValue(new Date().toString());
				rootElement.setAttributeNode(generated);
				
				//unionize items 
				Element items = doc.createElement("items");
				rootElement.appendChild(items);
				//create a hashmap of items and traverse through them
				HashMap<String,Integer> itemQty = poMarkers(POs); 
				
				Iterator it = itemQty.entrySet().iterator();
			    while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        Element item = doc.createElement("item");
			        items.appendChild(item);
			        Attr number = doc.createAttribute("number");
			        number.setValue(pair.getKey().toString());
			        item.setAttributeNode(number); 
			        Element quantity = doc.createElement("quantity");
					item.appendChild(quantity);
					quantity.appendChild(doc.createTextNode(pair.getValue().toString()));
			        it.remove(); 
			    }
				
				// write the content into xml file
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
	
				String dir1 = "/home/user/POReport/";
				new File(dir1).mkdirs();
				int rNumber = new File(dir1).list().length; 
				String rTot= rNumber < 10 ? "0"+rNumber : rNumber+"";
				String r = dir1+ "/report_"+rTot +".xml";
				StreamResult result = new StreamResult(new File(r));
				transformer.transform(source, result);
				
		 }catch (ParserConfigurationException pce) {
				pce.printStackTrace();
		 } catch (TransformerConfigurationException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private HashMap<String,Integer> poMarkers(List<String> POs) {
		String dir2 = "/home/user/PO/";
		HashMap<String,Integer> itemQty = new HashMap<String,Integer>();
		Iterator<String> it= POs.iterator();
		while(it.hasNext()) {
			try
			{
			String item = it.next(); 
			File oldfile= new File(dir2+item);
			File newfile = new File(dir2+"*"+item);
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			
			Document doc = dBuilder.parse(oldfile);
			NodeList iList= doc.getElementsByTagName("item");
			for(int i=0;i< iList.getLength();i++) {
				Node iNode= iList.item(i); 
				Element iElement= (Element) iNode; 
				if(itemQty.containsKey(iElement.getAttribute("number"))) {
					int qty = itemQty.get(iElement.getAttribute("number")); 
					String value= iElement.getElementsByTagName("quantity").item(0).getTextContent(); 
					qty= qty+ Integer.parseInt(value);
					itemQty.replace(iElement.getAttribute("number"), qty);
				}
				else {
					String key = iElement.getAttribute("number");
					String value= iElement.getElementsByTagName("quantity").item(0).getTextContent(); 
					itemQty.put(key, Integer.parseInt(value)); 
				}
			}
			oldfile.renameTo(newfile); 
			
			} catch (SAXException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParserConfigurationException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	return itemQty; 
	}
	
	
}
